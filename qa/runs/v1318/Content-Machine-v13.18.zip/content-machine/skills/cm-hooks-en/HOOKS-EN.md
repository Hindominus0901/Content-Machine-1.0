# Content Machine · Hooks

## §CM-HOOK-LIBRARY · The hook library: how it's used

### The hook library: how the lab uses it ("hook library", "more hooks", "hook ideas"; deepens §CM-HOOKS)
1 The lab (§CM-FORMATS 1, §CM-HOOKS) drafts from this library: ≥12 silent drafts, each filling one of the mandatory frames (§CM-PACKAGING 2, examples §CM-HOOK-TITLES); these mechanisms are raw material for the slots, chosen by the piece's purpose (ATTRACT, TRUST or CONVERT, as the week's plan says) and its surface; the next part says which suit which. Only the coach's facts and real buyer lines fill the slots. Every draft passes THE CHECK (§CM-HOOKS 2: desire or daily pain first · makes them ask "what do I get?" and "why now?" · right audience and moment, no insider detail · a number impressive at a glance, only theirs · tension, result promised, method hidden · one spoken sentence, medium length, the coach says I or we) or is dropped. An entry's example that would fail is a shape to rework, never a line to post. Only the winner prints.
2 Never shown to the coach: mechanism names, slots, the words "pattern" or "library", trap notes, codes or scores. The piece's type shows only as its plain word in the piece's title line (ATTRACT, TRUST or CONVERT, §CM-TIERS; the same rule as §CM-CAMPAIGNS 2), never on a hook. They see a hook, never how it was made. "Another hook" → 3 more, each from a mechanism not yet used for this piece.
3 Slots: {N}, {time}, {result}, {client role} take only their facts (dump, Card, hub, OK'd results). A research line becomes the viewer's own thought or "a line I keep seeing", never a client quote. No fact for a slot → another mechanism; if every strong draft needs it, one "[NEEDS: …]". In the examples, {N} is the coach's real number and the scenes are made up to show the shape; nothing here is posted as written.
4 Variety: no mechanism two pieces running; an opening not in recent_hooks (§CM-HUMANIZE); a week's ATTRACT pieces use ≥3 mechanisms.
5 Hard stops in every mechanism: no invented result, number, testimonial or scarcity; no deadline or cap that isn't real (§CM-GUARDRAILS); no income, weight or health promise; no attack on a person or group (the habit or the advice is the target); no bait ("you won't believe", "X is dead", "they don't want you to know", a freebie or money flex as the whole hook).

### Picking mechanisms by purpose and surface
1 Where: short = a short's first spoken line · screen = on-screen words · title = long-video title + thumbnail words · slide 1 = a carousel cover · post = line 1 of a long post · subject = email subject · chat = first line of a WhatsApp message or DM · ad = an ad's first line · live = a live or webinar title. One idea is rewritten for each surface, never pasted. An entry's example is written for its first surface; elsewhere it is cut to fit: screen ≤6 words (a text-led POV or "everyone says / reality" video: one line ≤15), title and slide 1 ≤60 characters, line 1 of a short or a post ≤12 words.
2 ATTRACT hooks are wide: a friend passes it on and the buyer feels named. Start from: belief flip, myth-bust, a moment from the buyer's day, call-out, cold open, overheard line, dare, starting over.
3 TRUST hooks show how the coach thinks. Start from: their number, costly mistake, confession, steps, behind the scenes, old vs new, how to X without Y.
4 CONVERT hooks speak to the decision the buyer is weighing. Start from: the objection said out loud, the question buyers ask, the after-state, a result taken apart, before → after, a challenge to join, "not for… / for…".
5 THE BAR (style only: other niches' example coaches; never their words or numbers, the coach's own go in): "Sold out Saturday, dead by Tuesday? 7 years baking from home, I fixed one thing." + "it's not the bread." · "How to answer 'can I see more photos first?' so couples book on the call." + "skip the portfolio." · "From 9 to 26 piano students in a year, no flyers: here's what I did." + "3x students" · "Give me 8 minutes, I'll give you 17 years of small-company bookkeeping." + "17 years → 8 min" · "Tax season is calm until you keep this one folder from January." + "not the software." · "Lovely nail photos, empty chair on weekdays? It's not your photos." + "stop posting more." · "A 5-day running challenge, 260 people, 59 joined the club: here's how I wrote it." + "59 runners." · "If I opened my nail studio again from zero, I'd do exactly 3 things." + "no salon yet." The shape: one of the frames (§CM-PACKAGING 2), their pain or desire first, then a promise or a turn; 2-4 thumbnail words after. Numbers decide who comes: the stage just above the buyer, never past the coach's proof.
6 "Hook library" or "more hooks" for a topic: ≤10 hooks for the next piece or the topic named, filled with their facts, grouped by surface, one line each, the one to post first on top. No names, no open slots. Then one question: which one to write.
7 A liked post the coach pasted (§CM-LIKED) maps to its nearest mechanism; the shape is borrowed, never the words.

## §CM-HOOK-FLIP · Flips, myths, old vs new, without

### Hooks 1: belief flip, myth-bust (shape · purpose · where · example · flat or trap)
BELIEF FLIP: the viewer believed A; the hook says B; the piece proves B.
1 "You don't need {usual fix}. You need {their answer}." · ATTRACT, TRUST · short, post, slide 1 · "You don't need more followers. You need these ten people." · Trap: a flip nobody believed ("you don't need to be rude").
2 "{Buyers} don't have a {named problem} problem. They have a {real cause} problem." · ATTRACT · short, title, subject · "Most freelancers don't have a pricing problem. They have this one." · Flat: "Pricing is about value."
3 "The {thing they do to fix it} is why {problem} stays." · TRUST · short, post · "Posting more and still nobody messages you? It's not the algorithm." · Trap: blaming the buyer; the habit is the target.
4 "Stop {common advice}. {Their move} instead." · ATTRACT · screen, short, ad · "Stop teaching a new student lesson one first. Do this instead." · Flat: "Tips for new teachers."
5 "{A strength they're proud of} is the problem." · TRUST · post, subject · "Answering clients at 11 pm and they still don't respect your hours? It's the thing you're proud of."
6 "Most {buyers} think {A} sells. It's {B}." · ATTRACT, CONVERT · post, title, live · "Most tutors think the trial lesson sells the course. Parents decide somewhere else."
7 "Not {usual fix}. Not {usual fix}. It was {their answer}." · TRUST · short, post, slide 1 · "Not the logo. Not more posts. It was one line on my price page." · Only fixes they saw tried; habits, never a rival's method.
MYTH-BUST: the advice they keep hearing, then what the coach sees: only the coach's own or a sourced view; health or money: "a belief I often hear", never a statistic.
8 "Everyone says '{advice}'. Here's what it skips." · ATTRACT · short, slide 1 · "Everyone says 'just niche down.' Here's the step it skips."
9 "'{Advice}' works, if you {condition nobody mentions}." · TRUST · post, title · "'Post every day' works if you know what your buyer's scared of."
10 "Myth: {belief}. Truth: {their answer}." · TRUST · screen, slide 1 · "Myth: good speakers don't prepare. Truth: they rehearse the first ten seconds." · Trap: "X is dead", "the truth they hide" (bait).
11 "{Belief}? {N} {things of theirs} say otherwise." · TRUST · post, subject · "Morning is the best time to run? {N} of my clients' run logs say otherwise." · Only their real logs, counts as kept.

### Hooks 2: old way vs new way, how to X without Y (shape · purpose · where · example · flat or trap)
OLD VS NEW: two ways, one wins. The old way is a habit or a piece of advice, never a person or a group.
1 "Old way: {habit}. New way: {their way}." · TRUST · screen, slide 1, post, ad · "Old way: a 40-minute sales call. New way: three questions before the call."
2 "Most {buyers} {old move}. The ones who {result} {new move}." · ATTRACT · post, short · "Most new photographers send a price list. The ones who stay booked send this first."
3 "{Copied option} vs {their way}: what each costs you by {time}." · CONVERT · post, slide 1, subject · "A template vs your own words: what each costs by month three."
4 "Two {buyers}, same {situation}. One {did A}. One {did B}." · ATTRACT · short, post · "Two shop owners, same slow month. One cut prices. One called five old customers." · A made-up pair is said as one ("picture two shop owners"), never as a true story.
5 "Alone vs with {a plan}: both work. One costs {honest cost}." · CONVERT · post, live, chat · "Fixing your website alone vs with a checklist: both work. One takes your whole weekend." · Trap: making the buyer's way look stupid; the honest trade-off is the hook.
HOW TO X WITHOUT Y: the result, and the bracket removes a fear that is real.
6 "How to {result} (without {what they fear})" · TRUST · title, slide 1, subject · "how to raise your prices (without losing your regulars)" · Flat: "Pricing strategies for small businesses."
7 "{Result}, even if you {constraint}." · ATTRACT · short, post, live · "Lead meetings in English, even if you still translate in your head."
8 "{Result} without {what they think it takes}: {N} things I'd keep" · TRUST · slide 1, post · "A full calendar without daily posts: the 3 things I'd keep" · {N} is the real count in the piece.
9 "The lazy way to {result}: {small surprising move}." · ATTRACT · short, screen · "The lazy way to get referrals (it takes one message)."
10 "No {feared cost}. No {second cost}. Just {their way}." · CONVERT · ad, live · "No cold messages. No daily posting. Just one line in every follow-up." · Trap: "without effort", "without ads" when it isn't true; the bracket removes a real fear, never the work.
11 "{Task} is hard until you {do X} like this" · TRUST · title, slide 1 · "Pricing is hard until you write it like this"

## §CM-HOOK-PROOF · Their number, real results, before and after

### Hooks 3: their number, a real result taken apart (shape · purpose · where · example · flat or trap)
THEIR NUMBER: only their own counts, exact, never rounded up; the number decides who comes.
1 "I've {done X} {N} times. One thing mattered." · TRUST · short, post, slide 1 · "I've read {N} sales-call notes. One sentence decided most of them." · Trap: a borrowed or rounded number.
2 "{N} boring {habits} that {result}" · TRUST · slide 1, post, subject · "{N} boring habits that keep my calendar full" · Their real habits and N only.
3 "{N} years of {work} in {N} minutes" · TRUST · title, live · "{N} years of teaching beginners to swim, in 9 minutes" · Minutes = the video's real length.
4 "{N} of my last {N} {clients} {did the same thing} first." · TRUST · short, post · "{N} of my last {N} clients made the same first mistake."
5 "{Count from the buyer's day}. {What it costs}." · ATTRACT · screen, short · "4 drafts. 0 posts. Another week gone." · A scene count, never a statistic.
6 "I tracked {thing} for {time}. {What the count showed}." · TRUST · post, title, subject · "I timed every first call for {time}. Every yes came before minute {N}." · Only if they tracked it.
7 "Give me {N} minutes and I'll show you {the fix for their pain}" · TRUST, CONVERT · title, live · "Give me {N} minutes and I'll fix your price page's first line" · {N} = the real length; the fix lands inside it.
RESULT TAKEN APART: a real result, the client's written OK, the context in the piece.
8 "How {client role} went from {before} to {after}: the {N} decisions" · CONVERT · title, live, post · "How a bakery owner went from {before} to {after}: the 3 decisions" · Trap: a result with no context (starting point, time, what else changed) or no OK.
9 "A {client role} asked me {question}. Here's what we changed." · CONVERT, TRUST · short, title · "A wedding photographer asked me why her inquiries went quiet. Here's what we changed." · Only a question the coach reported.
10 "The {one change} behind {client role}'s {result} (and what didn't matter)" · CONVERT · post, subject, slide 1 · "The one email behind {a client's OK'd result} (and the three things that didn't matter)"
11 "My numbers from {launch, month}, the bad one too" · TRUST · post, subject, chat · "My workshop numbers, including the one I'd rather hide" · Trap: only the wins; the miss earns the trust.

### Hooks 4: before and after, the after-state (shape · purpose · where · example · flat or trap)
BEFORE → AFTER: their own change, or a client's with a written OK and its context.
1 "From {before} to {after} in {time}: what {client role} changed" · CONVERT · title, slide 1, live · "From {before} to {after} in {time}: what one tutor changed in her first message" · Trap: body, income or health before/after as the hook; never in ads.
2 "{Time} ago I {before}. This week I {after}." · TRUST · post, short · "A year ago I dreaded Sunday nights. This Sunday I planned the week before dinner." · Their own change only.
3 "{Before object} → {after object}" · ATTRACT · screen, slide 1 · "A 3-page price list → one line."
4 "Same {person}, same {offer}, one change: {what}." · TRUST · short, post · "Same coach, same offer, one new first sentence."
5 "{Before} vs {after}, hour by hour" · ATTRACT · slide 1, post · "A Monday with no plan vs a Monday with one, hour by hour."
6 "{Client role} {did X} for {time} and nothing moved, until {one change}" · CONVERT, TRUST · post, title · "A yoga teacher posted daily for {time}. Nothing moved, until one change." · Her written OK; the change is named in the piece.
AFTER-STATE: the buyer's day once the problem is gone, in things they'd see; never a number they'd reach.
7 "The week {problem} is gone, you'll notice it at {small moment}." · CONVERT · post, ad, chat · "The week your follow-ups are written, you'll notice it at dinner. The phone stays face down."
8 "First time {buyer} {small after-moment}." · ATTRACT, CONVERT · screen, short · "First time she sent the invoice without saying sorry."
9 "What {after} feels like (it's not {what they expect})" · TRUST · post, subject · "What a full calendar actually feels like (it's not relief)"
10 "If {problem} were fixed by {day}, what would you do first?" · CONVERT · chat, ad, live · "If your price page were done by Friday, who's the first person you'd send it to?" · Trap: an after-state the offer can't deliver; show the process's day, never a promised result.
Flat: "Imagine your dream business." · Strong: entry 7.

## §CM-HOOK-SCENE · Scenes, overheard lines, the buyer's day

### Hooks 5: cold open, the overheard line (shape · purpose · where · example · flat or trap)
COLD OPEN: one scene the viewer has lived, said so they see themselves (never an insider's detail), no setup; line 2 must cost something. Spoken as line 1 it still fills a frame (§CM-HOOK-SHORT 3); a bare scene is for the screen or first frame only.
1 "{Time}. {Object or action}." · ATTRACT, TRUST · short, post · "Rewriting your price page for the fourth time at midnight? Stop at this line."
2 "Last {day}, {who} {small act}." · TRUST · post, chat · "Last week a client sent me her empty inbox. If yours looks the same, watch this." · A client's words only if the coach reported them.
3 "{Object} on {place}: '{what it says}'." · ATTRACT · screen, short (as the first frame) · "A sticky note on her screen: 'don't say sorry.'"
4 "The {object} I still keep from {moment}" · TRUST · post, short · "Still opening invoices with 'sorry'? I kept my first one; it says it twice."
5 "I was {mid-action} when {someone} said '{line}'." · TRUST, CONVERT · post, live (after a framed line 1) · "I was mid-pitch when he cut in: 'What do I actually get?'" · Trap: a scene with no tension (a coffee, a sunrise).
OVERHEARD LINE: a line the buyer says or hears, framed honestly: reported by the coach, or "a line I keep seeing".
6 "'{Exact buyer line}.' {Where it's heard}." · TRUST · short, post · "'I'll start posting when my website's done.' A line I keep seeing in freelancer groups."
7 "Someone in {buyer place} wrote: '{line}'. {Turn}." · ATTRACT · post, slide 1 · "Someone in a freelancer group wrote: 'I'm busy but broke.' Both can be true for one reason."
8 "'{What they say}' means '{what they mean}'." · ATTRACT · screen, slide 1 · "'Just send me the price' never means what you think."
9 "The sentence I hear right before {outcome}" · TRUST · short, post · "The sentence I hear right before someone quits running? 'I'm just not built for it.'"
10 "My {relative} said '{line}'. {Half right}." · ATTRACT · short, post · "My mum said, 'Who'd pay for that?' She was half right."
Trap for both: a line put in a client's mouth the coach never reported; a research line stays "a line I keep seeing", never "my client said".

### Hooks 6: a moment from the buyer's day, behind the scenes (shape · purpose · where · example · flat or trap)
MOMENT FROM THE BUYER'S DAY (§CM-MOMENTS): who, when, the exact line or object, the feeling.
1 "POV: {time} and your {client, staff, kid} just {exact action}." · ATTRACT · screen, short · "POV: it's 10:47 pm and a client texts 'quick question 🙂'."
2 "Anyone who's {small specific experience} knows this one." · ATTRACT · screen, post · "Anyone who's run a two-hour live for three viewers knows this one."
3 "Everyone says '{advice}'. Reality:" · ATTRACT · screen, slide 1, ad · "Everyone says 'batch your content.' Reality: Sunday, 9 pm, one draft, cold tea."
4 "The {N} stages of {buyer moment}" · ATTRACT · slide 1, short · "The 5 stages of sending your first price quote"
5 "Things nobody tells you about {milestone}" · ATTRACT, TRUST · slide 1, title, subject · "Things nobody tells you about your first paying client"
6 "You {did X} today. You {did Y}. {What links them}." · ATTRACT · short, post · "You checked your inbox six times today. You rewrote one caption twice. Same fear." · Both acts from buyer lines, never a guess.
7 "Explaining {the buyer's choice} to {family}" · ATTRACT · screen, short · "Explaining to your parents why you quit a stable job to freelance" · The laugh is on the situation, never the family.
Trap: the buyer as the joke; the coach or the situation takes the laugh.
BEHIND THE SCENES: the coach's real work, shown, never the lifestyle.
8 "What I do in the {N} minutes before {key moment}" · TRUST · short, post · "What I do in the 10 minutes before every first call"
9 "The {sheet, list} I open before every {task}" · TRUST, CONVERT · screen, slide 1 · "The one-page sheet I open before every client session" · It becomes the gift (§CM-HOOK-CTA).
10 "{Fixing X} live, for a real {client role}" · TRUST, CONVERT · live, title · "Fixing a real price page, live (bring yours)" · Real person, their OK.
11 "The exact message I send when {situation}" · CONVERT · post, short, subject · "The exact message I send when a trial student doesn't sign up"
12 "A week of {their work}, unedited: where the hours went" · TRUST · post, title · "A week of running a one-person practice, unedited: where the hours went"
Trap: a laptop by the pool; show the work, not the life.

## §CM-HOOK-CALLOUT · Call-outs, questions, objections, challenges

### Hooks 7: the buyer's situation called out, the question they ask (shape · purpose · where · example · flat or trap)
CALL-OUT: their stage or situation, never their worth.
1 "If you're {stage or situation}, watch this." · ATTRACT · short, title · "If you've posted six months and nobody's asked your price, watch this."
2 "{Buyers} with {specific situation}: {one-line diagnosis}." · ATTRACT · screen, post · "Tutors with full weeks and empty accounts: it's not your rate."
3 "For the {buyer} who {small private habit}." · ATTRACT · short, post, chat · "For the coach who writes a caption, then deletes it at midnight."
4 "{Buyers} at {stage}: your next step isn't {usual step}." · TRUST · title, slide 1 · "First-year photographers: your next step isn't new gear."
5 "Still {doing X} at {time}?" · ATTRACT · ad, screen · "Still answering client messages at 11 pm?"
6 "Not for {wrong buyer}. For {right buyer}." · CONVERT · post, live, ad · "Not for people chasing followers. For tutors who want a few students who stay all year."
Trap: a call-out by worth or flaw ("lazy", "broke", "failing"); the stage, never the person.
THE QUESTION BUYERS ASK: their exact words (DMs, calls, comments, research), answered by the piece.
7 "'{Their exact question}?' {Short answer}." · CONVERT, TRUST · short, post, chat, ad · "'Do I need a website first?' No. You need this first."
8 "The question {buyers} ask me most (and the answer they don't like)" · TRUST · title, subject · "What new coaches ask me most (the answer they won't like)"
9 "You asked: {question}. The {N}-{part} answer." · TRUST · post, slide 1 · "You asked: how do I follow up without being annoying? The 3-message answer."
10 "What should {buyer} charge for {X}? The honest math." · CONVERT · title, post, live · "What should a beginner charge for a logo? The honest math."
11 "{Their question}: {N} minutes, live, bring your {thing}." · CONVERT · live, chat · "Why your inquiries go quiet: 30 minutes live, bring your last message."
Trap: a question nobody asks in those words ("Are you ready to transform your business?"). Flat: "Struggling with sales?" · Strong: entry 7.

### Hooks 8: the objection said out loud, the challenge (shape · purpose · where · example · flat or trap)
OBJECTION: said in the buyer's words (calls, DMs, research), then answered like a friend would.
1 "'{Objection}.' I said that too, for {time}." · TRUST, CONVERT · short, post · "'I don't have time to post.' I said that too, for two years."
2 "'{Objection}?' Fair. Here's what actually happens in {first step}." · CONVERT · short, ad, chat · "'Isn't coaching just expensive advice?' Fair. Here's what actually happens in week one."
3 "The real reason you {hesitate} (it's not {stated reason})" · TRUST · title, subject, post · "The real reason you undercharge (it's not your clients)"
4 "You're not {label they fear}. You're {reframe}." · ATTRACT, TRUST · short, screen, subject · "You're not bad at sales. You're missing one thing."
5 "'{Objection}' is a good reason to wait, if {condition}." · CONVERT · post, chat, live · "'Now's not the right time.' A good reason to wait, if you know what changes by then."
Trap: mocking the objection or the person who has it. Flat: "Common objections and how to handle them."
CHALLENGE: one small action the viewer can try today, or one the coach tried first; never a body, money or health result.
6 "Try this for {N} days: {one small action}." · TRUST, CONVERT · short, post, chat · "Try this for 7 days: one question before any price."
7 "I dare you to {small brave act} this week." · ATTRACT · screen, short · "I dare you to post the draft you deleted last night."
8 "Do this before you {common next step}." · TRUST · short, title · "Before you buy another course, write down three questions clients asked you."
9 "{N} days, {one thing}: we start {real day} in {place}." · CONVERT · live, chat, post · "5 days, one price page: we start Monday in the group chat." · A real start and place only; a join count or "last spots" only if true.
10 "I tried '{common advice}' for {N} days. {What happened}." · ATTRACT, TRUST · short, post, title · "I tried 'post every day' for {N} days. Here's what my inbox did." · Only if they did it; the whole ending, the bad part too.
Trap: a challenge that promises weight, income or health results, or a fake deadline to join.

## §CM-HOOK-MISTAKE · Mistakes, confessions, starting over, steps

### Hooks 9: the costly mistake, the confession (shape · purpose · where · example · flat or trap)
COSTLY MISTAKE: common, fixable, named in the buyer's words; the viewer is never the joke.
1 "{N} mistakes {buyers} make with {X}" · TRUST · title, slide 1, subject · "3 mistakes new tutors make with their first price" · {N} is the piece's real count.
2 "The small mistake that makes {buyers} {cost in their words}" · ATTRACT · short, post · "The small mistake that makes trial students drop after lesson one"
3 "Don't {common move} until you {check}." · ATTRACT, TRUST · title, short · "Don't post a price until you've written the line above it."
4 "If your {effort} gets {what they see now} but no {what they want}, {fix}." · TRUST · title, post · "If your posts get likes but no DMs, check this first."
5 "Your most expensive habit: {habit}." · ATTRACT · screen, subject · "Your most expensive habit: saying 'no worries' when a client pays late."
6 "I watched {client role} lose {what, in their words} to one {small mistake}." · TRUST · post, short · "I watched a client lose a whole weekend to one vague email." · Only what they saw happen.
Trap: "stupid mistakes", shaming. Flat: "Avoid these mistakes."
CONFESSION: the coach's own wrong turn and what it cost; people trust the one who admits it.
7 "I {did the wrong thing} for {time}. {What it cost}." · TRUST · post, short, subject · "I undercharged for {time}. It cost me the clients I actually wanted."
8 "I ignored {X} (it cost me {Y})" · TRUST · subject, title · "I ignored my email list (it cost me a launch)"
9 "The most embarrassing {moment} of my {first year}" · ATTRACT · short, post · "The most embarrassing sales call of my first year"
10 "{N} years of {work}, and I still {small flaw}." · ATTRACT, TRUST · short, post · "{N} years teaching public speaking. My hands still shake on line one."
11 "I've never said this on a {sales call}: {honest truth}." · TRUST, CONVERT · post, chat, live · "I've never said this on a sales call. Some of you shouldn't hire me yet."
Trap: a humble brag ("my flaw is caring too much"); the confession must cost something real.

### Hooks 10: if I started over, the list or steps (shape · purpose · where · example · flat or trap)
IF I STARTED OVER: what they'd do from zero, with what the viewer has.
1 "If I had to {get result} from zero, I'd {first move}." · TRUST · short, title, slide 1 · "If I had to find clients from zero this month, I'd do exactly this."
2 "If I started {work} today, I'd skip {common thing}." · ATTRACT · short, post · "If I started tutoring today, I'd skip the one thing everyone builds first."
3 "What I'd tell myself on day one of {work}" · ATTRACT · post, slide 1, subject · "What I'd tell myself the day I quit my job to coach"
4 "{N} years in, the first thing I'd build again: {thing}" · TRUST, CONVERT · title, live · "{N} years in, the first thing I'd rebuild: my follow-up list"
Trap: starting over with what the viewer doesn't have (a team, an audience, a budget).
LIST OR STEPS: the number is the real count in the piece; one unexpected plain word helps.
5 "{N} steps to {result} (most stop at step {n})" · TRUST · slide 1, title, post · "4 steps to a price page that sells (most stop at step 3)"
6 "{N} things I'd check before you {decision}" · CONVERT · slide 1, subject, post · "5 things I'd check before you hire any coach (me included)"
7 "{N} signs you've {situation}" · ATTRACT · slide 1, subject · "7 signs you've outgrown free calls"
8 "The {N} stages of {X} (most {buyers} stall at {n})" · TRUST · title, slide 1 · "The 4 stages of a tutoring business (most stall at stage 2)"
9 "Steal my {N}-step {routine}" · TRUST, CONVERT · slide 1, post, short · "Steal my 3-step Sunday plan" · The steps become the gift.
10 "{N} {plain word} {things} that {result}:" · TRUST · post, slide 1 · "7 quiet signals a client will actually buy:" · LinkedIn and long posts: the line ends in ":".
Trap: ten steps where three do the work. Flat: "Tips for growing your business."

## §CM-HOOK-SHORT · A short's three hooks

### A short's three hooks: on-screen words, first frame, first line (one idea, three jobs)
1 On-screen words (≤6, read with the sound off) name the tension or ask the question. The first frame shows one filmable thing that makes it real. The first spoken line (≤12 words) opens the loop in the buyer's words. None repeats another: on-screen is never line 1 reworded, never the frame captioned.
2 Last line first: write the payoff word for word (the answer, never its name), then the three hooks that point at it.
3 By frame (on-screen · first frame · first line → line 2, the proof); every first line fills a frame (§CM-PACKAGING 2):
- call-out: "stop posting more." · a liked feed, no bookings · "If your nail photos get likes but the weekday chair stays empty, watch this." → "I posted daily for {time} and got {N} weekday bookings. Then I changed one thing."
- give me N minutes: "17 years → 8 min" · a desk stacked with receipts · "Give me 8 minutes, I'll give you 17 years of small-company bookkeeping." → "{N} years of books; most mistakes I fix start in January."
- start over: "no website yet." · a blank notebook · "If I had to find 5 clients from zero this month, I'd do exactly this." → "It's how I found my first {N}."
- you're losing: "fix it in 5 min." · a trial sheet with gaps · "Teach the trial lesson the usual way and you lose a student a month." → "{N} of my last {N} trial students never came back, before I changed it."
- hard until: "not the bread." · a fresh tray · "Selling bakes online is hard until you post at this hour." → "That hour took my Tuesday orders from {X} to {Y}."
- receipt: "3x students" · a full teaching timetable · "I went from 9 to 26 piano students in a year, no flyers." → "Same fee, same room; only the trial lesson changed." Receipt: the coach's own number; a client's result only in line 2, OK'd.
The buyer's moment (a trial student who never comes back) comes at line 3, never as the hook.
4 Flat: on-screen "keep receipts from January." + first line "December: a box of receipts, a panicked call to the accountant. Sound familiar?" (the method on screen, a scene as the hook, no frame). Strong: on-screen "not the sales post." · frame: scrolling back to a post from months ago · line "If your sales post gets likes but no buyers, watch this." · line 2 "{N} of my clients decided weeks before it." · last line "They decided on the posts before it; the sales post is only the invitation."
5 Funnel shape for TRUST shorts (§CM-HOOKS 5): the three hooks stay wide; the buyer's own words come in the next 2-3 lines so the wrong crowd scrolls on.
6 Caption line 1 continues the hook from a fourth angle (a fact, a stake), never a copy; the ask stays in the caption (§CM-HOOK-CTA).

## §CM-HOOK-TITLES · Titles, thumbnail words, live titles

### Title + thumbnail words, live and webinar titles
1 Package first (§CM-PACKAGING): about 20 title drafts, every one filling a frame below, then THE CHECK (§CM-HOOKS 2). The title says who + what they get, ≤60 characters, casual case fine, no hedge. The thumbnail adds 2-4 words the title doesn't say, one of: a big real number, the result, or a verdict or dare that hides the method. A short's first spoken line is the title said aloud; line 2 is proof (their real number or story); the scene starts at line 3.
2 THE FRAMES (mandatory; title + thumbnail, their numbers only; examples from other niches, style only):
- give me N minutes: "Give me 8 minutes, I'll give you 17 years of small-company bookkeeping" + "17 years → 8 min"
- call-out: "Studied English 3 years and still freeze in meetings? Watch this" + "stop learning words."
- hard until: "Selling bakes online is hard until you post at this hour" + "not the bread."
- start over: "If I opened my nail studio again from zero, I'd do exactly this" + "no salon yet."
- N ways (objection removed): "3 replies when a couple asks for a cheaper package (no discount)" + "keep the package."
- receipt: "I went from 9 to 26 piano students in a year. No flyers." + "3x students"
- so X that Y: "Running coaching so gentle students ask for tomorrow's run" + "no pushing."
- you're losing: "You're losing students at every trial lesson (here's the fix)" + "fix it in 5 min."
- they asked me: "A {N}-location owner asked me how to hit {N+2} without more staff" + "{N} → {N+2}"
- 3-line image post: "The bake-photo formula / that turns a Tuesday post into orders / even if you never run ads"
3 Never: thumbnail words that repeat a title word or state the method ("keep receipts from January.", "post at 6."), a shocked face, money or income as the hook, a number that isn't theirs, a scene as the title, a promise the video doesn't keep in its first minute. Would it sit in a top business-YouTube grid? No → redraft.
4 Live or webinar title: the result + who it's for + what they bring or leave with; the intro then runs proof, promise, plan (§CM-LONG-INTRO). "Fix your price page live: 45 minutes for tutors (bring yours)". The time, the place and any replay promise are real; "seats" only if there's a real cap.
5 The title's promise is met early: line 2 starts the proof.
6 Re-title once, by the rule in §CM-PACKAGING 5: a new title OR new thumbnail words, never both.
Flat → strong: "My thoughts on pricing" → "3 ways to raise your prices (without losing regulars)" · "Q&A session" → "bring the post that got no bookings: live fixes, 45 minutes".

### Two more frames: belief flip, myth / truth (item 2 above; v13.15)
Both are mandatory frames like the ten above (§CM-FORMATS 1). The belief is one the buyer really holds (their words, a KEEP line), the truth is the coach's own (or sourced) and the piece proves it; health or money: "a belief I often hear", never a statistic; never "X is dead" or "the truth they hide" (§CM-HOOK-FLIP).
- belief flip: "Everyone says discount to fill a slow week. My fullest month had no discount." + "keep the price."
- myth / truth: "Myth: tutors need ads. Truth: 4 of my 5 new students came from one parents' group." + "1 group → 4 students"

## §CM-HOOK-TEXT · Slide 1, line 1, subjects, chat openers

### Carousel slide 1, line 1 of a long post
CAROUSEL (§CM-TEXT-FORMATS 1)
1 Slide 1 is a promise the slides keep: the result in buyer words, ≤60 characters, two lines of big type. A number only if it is the real count of slides or steps. Never a label ("Start here", "Tips for coaches"), a hedge, the brand name or a "→" doing the work.
2 Mechanisms that suit slide 1: list or steps, mistakes, signs, stages, old vs new, myth vs truth, "steal my…", things nobody tells you, the question they ask.
3 Slide 2 keeps them reading: why listen (one fact of theirs) or the stake. The last slide answers the loop, then this carousel's gift + its keyword (§CM-HOOK-CTA).
4 The cover reads alone in a feed or shared into a group: it makes sense with no caption.
5 Flat → strong: "Pricing tips for freelancers" → "5 lines that make a price feel fair (before you say it)" · "Content strategy 101" → "What to post when nobody's buying yet" · "My morning routine" → "The {N} minutes that decide my whole client day".
5b FRAME CHECK, slide 1 like any hook (§CM-FORMATS 1): a frame, no client name, no insider number only a client would get. Fail: "Hannah's salon: 9 → 26 bookings. 3 photos, 2 captions." → Pass: "Nail photos get likes but no bookings? 5 fixes (no new photos)."
LINE 1 OF A LONG POST (§CM-POSTS 1)
6 Line 1 ≤12 words, standing alone, fills a frame (§CM-PACKAGING 2): the buyer's desire or pain for the right person at the right moment, their number; the method stays hidden; never a scene, a maxim or a stated lesson. Line 2 raises the stake or turns it. Both land before "See more".
7 Strong: "If your nail photos get likes but no weekday bookings, read this. / It's not the photos." · "I went from 9 to 26 piano students. / Same fee; only the trial lesson changed." Flat: "Today I want to talk about pricing." · "Pricing is one of the hardest parts of business."
8 LinkedIn: line 1 may end in ":" for a list ("7 quiet signals a client will actually buy:"); paragraphs and hashtags as §CM-POSTS 3-4, ≤1 emoji.
9 Facebook long post: line 1 fills a frame, never a scene or a greeting; line 2 is the proof or the turn ("Not because of the price."), so the cut-off reads like a cliffhanger.

### Email subjects, chat openers (WhatsApp, DM)
EMAIL (§CM-TEXT-FORMATS 2)
1 The subject is in buyer words, one idea, about 4-9 words, lowercase fine. The preview line adds (like thumbnail words), never repeats. The email's first line starts paying off the subject.
2 Shapes: how I {result} (with {limit}) · I ignored {X} (it cost me {Y}) · {N} signs you've {problem} · a reframe ("you're not lazy. you're unclear.") · the question they asked ("do I need a website first?") · a scene ("the email I almost didn't send") · a confession ("I undercharged for {time}").
3 FRAME CHECK (§CM-FORMATS 1): the subject fills a frame like any hook, no client name. Fail: "This week's update" · "My new student" → Pass: "if your students quit halfway, read this" · "I stopped assigning scales, now they finish songs".
3b Flat → strong: "Newsletter #12" → "the client who cancelled (good thing)" · "Pricing tips" → "I charged too little for {time} (here's the math)" · "Exciting news!" → "doors open Monday: {N} seats, here's why {N}" (only with a real cap and its reason).
4 Never: a fake "Re:" or "Fwd:", "last chance" or "closing tonight" unless it's true (§CM-GUARDRAILS), all caps, a subject the email doesn't pay off, a gift the email doesn't hold.
5 Launch emails say what happens and when, plainly; real dates and seats only (§CM-LAUNCH-DAYS).
CHAT OPENER (WhatsApp, a DM)
6 First line = who you are + why you're writing (never their name, §CM-MESSAGES 6), the way one person texts another; the chat list shows only the start, so the reason goes there. "Hi, it's {your name} from Tuesday's workshop: the checklist you asked for is below."
7 Broadcast to a list or group: line 1 is a scene or their question, never "Dear valued customer" or "Hello everyone, I hope you're well".
8 One message, one job; the offer only when they asked or opted in; a follow-up gives an easy exit ("if now's not the time, ignore this one").
9 Flat → strong: "Hello! I have an exciting offer for you" → "Hi, it's {your name} from the pricing live: you asked about the next round, it opens Monday."

## §CM-HOOK-ADS · Ad hooks

### Ad hooks (from a post that already worked; deepens §CM-ADS)
1 Keep the organic hook that brought messages; change only what ad rules need. A test runs 3 hooks from 3 different mechanisms, one audience, no edits midway (§CM-ADS 5).
2 The pain or the situation, never the person: "Still rewriting your price page at midnight?", never "Are you broke?", "Overweight?", "Struggling with anxiety?". Age, money, body, health and beliefs are never said as "you are…".
3 Mechanisms that suit ads: the situation called out · a moment from their day · the objection said out loud · how to X without Y (a true bracket only) · the question they ask · old vs new · the after-state as a process ("one hour on Sunday and the week is planned"), never a result.
4 Off limits: income, weight or health results; before/after; money screenshots; "comment X" (the button does it); coded spellings; a famous name they don't have permission to use; urgency that isn't real. Proof only with an OK for ads.
5 Video ad vs headline: the first spoken line is the pain moment; the headline under it is the outcome in plain words; they never say the same thing.
6 Warm audiences (watched, engaged, messaged): a hook that remembers them ("You watched the price-page video. Here's the checklist that goes with it."). Cold audiences: the situation hook.
7 Flat → strong: "The best coaching program for freelancers!" → "Your trial lessons are full and nobody signs up after." · "Lose weight fast!" → "Too tired for the gym after work? A plan built for the 20 minutes you do have." (the process, no result) · "Limited time offer!" → the real close: "Sign-ups close Friday 8 pm; the next round is in spring."
8 Money, health or body offers: the hook names the process, and under the ad ONE line, the platform note in §CM-ADS 7.

## §CM-HOOK-CTA · CTA lines by rung

### CTA lines by tier (the ask closes the loop the hook opened)
1 Tiers, rotated (§CM-CTA-KIT 1): ATTRACT → save or send · TRUST → comment for THIS piece's payoff · CONVERT → DM with the real offer and a real deadline (outside a launch, from week 2; Week 1's CONVERT piece asks for a reply, no offer). One ask per piece, never the same ask twice running; ≥1 in 4 pieces asks only for a save or send. The payoff exists before the post goes out (§CM-CTA-KIT 2).
2 ATTRACT: "Save this for the next time a couple asks for a cheaper package." · "Send this to the friend who {situation}." · "Part 2 tomorrow: {the open question}." · a choice: "Do you file receipts monthly or all in December? Just type A or B." Never "thoughts?".
3 TRUST: "Comment {WORD} and I'll send you {payoff}.", {payoff} = what this piece promised: "Comment TUESDAY BAKE and I'll send you the 3 posting times from this video." {WORD}: the viewer's own words from the hook, by the keyword table (§CM-CTA-BANK 2), never a machine-picked GUIDE or FREE. Quiet style (§CM-CTA-KIT 5): "Message me {WORD} and I'll send you {payoff}."
4 CONVERT (week 2+, with proof): what they get, the exact price, who it's for, the real deadline or cap with its reason, one action: "{N} seats, because I review every page myself; sign-ups close Friday. Message me SAVE MY SEAT." · "If this is you, message me STILL STUCK and say where you are; I'll reply myself." The Season {KEYWORD} and gift live here by default (once, body or caption). Only real numbers.
5 Link: in a comment, the bio or the description, never in a text post's body: "The checklist is in the first comment."
6 The coach's own choice ("." (a dot), "comment if…", "when this hits 100 comments", an emoji): word for word, never softened; under it ONE line: "Platform note (as of {date}): Facebook and Instagram may show 'comment if…' posts to fewer people. Your call." (§CM-CTA-KIT 6).
7 Each mechanism's natural payoff: their number → the sheet behind it · mistake → the checklist · objection → a message to talk it through · question → the full answer · challenge → join (real start) · after-state, result taken apart → the offer.
8 Never: fake urgency ("only 3 left" when it isn't), "Don't miss out", "DM for price" on a fixed-price offer, a payoff not yet written, two asks in one piece, one generic "comment X" on every piece.
Flat → strong: "Follow for more tips!" → "Part 2 tomorrow: the one line I'd add to your price page." · "Comment GUIDE for my free guide" → "Comment PRICE CHECK and I'll send the price sheet from this video." · "Thoughts?" → "What hour do you post your bakes? Just type the hour."
