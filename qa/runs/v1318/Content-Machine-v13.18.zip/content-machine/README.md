# Content Machine — plugin

Tiếng Việt: gõ `Bắt đầu` · English: type `Start`

## Tiếng Việt

Một file `content-machine-plugin.zip` dùng cho cả Claude và ChatGPT, có cả tiếng Việt lẫn tiếng Anh. Để nguyên file zip, không giải nén.

**Claude (Pro)**
1. claude.ai trên máy tính → Customize → Plugins → Add → Upload plugin → chọn file zip.
2. Nếu Claude báo cần Code execution: Settings → Capabilities → bật lên.
3. Mở chat mới (web, máy tính hay điện thoại), gõ `Bắt đầu`.

**ChatGPT (Plus/Pro)**
1. Settings → Security and login → bật Developer mode.
2. Mục Plugins → tải file zip lên.
3. Mở chat mới, gõ `Bắt đầu`.

Hôm sau: nhắn `tiếp` ngay trong đoạn chat cũ. Mở chat mới thì dán Brand Card vào trước.

**Có sẵn thêm:** chín skill đồng hành, mỗi nâng cấp một skill (nghiên cứu, mở bán và quảng cáo, chiến dịch mở bán, hub và tác vụ hẹn giờ, chiến lược, thư viện hook, file chiến lược, ngân hàng nội dung, viết bài), và bốn agent phụ cho Claude Code và Cowork. Không cần tải gì thêm: cần việc nào thì skill đó tự mở.

## English

One file, `content-machine-plugin.zip`, for both Claude and ChatGPT, with the English and the Vietnamese edition in it. Keep it zipped; do not unzip it.

**Claude (Pro)**
1. claude.ai on a computer → Customize → Plugins → Add → Upload plugin → choose the zip.
2. If Claude says it needs Code execution: Settings → Capabilities → turn it on.
3. Open a new chat (web, desktop or phone) and type `Start`.

**ChatGPT (Plus/Pro)**
1. Settings → Security and login → turn on Developer mode.
2. Plugins → upload the zip.
3. Open a new chat and type `Start`.

Next day: say `next` in the same chat. In a new chat, paste the Brand Card first.

**Also inside:** nine companion skills, one per level-up (research, launch and ads, launch campaigns, hub and scheduled tasks, strategy, hooks, the playbook, banks, copywriting), and four helper agents for Claude Code and Cowork. Nothing to upload: they load when the job needs them.
