# Content Machine · Mở bán

## §CM-LAUNCH · Chọn kiểu, tính số

### Mở bán ("ra mắt khoá", "mở lớp mới", "launch")
1 Mỗi lần một đợt; năm 2–4 đợt lớn, giữa hai đợt lớn ≥6 tuần đăng bình thường; mở lại cùng sản phẩm (§CM-CAMPAIGN-RELAUNCH) không tính vào đó, tối đa tháng một lần. Tháng cô hồn: §CM-LOCALE 6.
2 Đọc trước, hỏi sau: sản phẩm, giá, bằng chứng, danh sách, kênh lấy từ Card, Bản đồ (§CM-GUARDRAILS). Rồi chọn kiểu, mỗi tin một câu, rõ là dừng:
a "Đã có ai trả tiền học khoá này (hay bản gần giống), có kết quả và đồng ý cho {xưng hô} kể chưa?" Chưa → A.
b "Khoá này {xưng hô} mở bán rồi, có đợt nào đạt số đặt ra chưa?" Rồi → D.
c "Đợt này {xưng hô} live được mấy buổi?" 0 → B; 1–2 → B kèm một buổi live (trừ khi còn đủ 21 ngày và muốn danh sách đông hơn: khi đó C, dạng lớp nhóm); 3+ và còn đủ 21 ngày → C.
3 Các kiểu, nói lời thường với coach:
A Suất nhóm đầu: chưa có bằng chứng. Khoá đầu, giá nhóm đầu, đổi lại học viên góp ý. 7 ngày, mở bán 3 ngày. Bằng chứng là quy trình, bản làm mẫu, không "học viên đã…".
B Mồi (mặc định): quà → inbox → Zalo → đổi niềm tin → giá trị → chuyện khách → mở bán. 14 ngày, mở bán 6 ngày. Không live: video quay sẵn ≈1.500 chữ thay.
C Lớp mini Zalo (hay thử thách 5 ngày): 3 tối trong nhóm Zalo + 1 buổi live. 21 ngày, mở bán 6 ngày.
D Chạy lại: bài đã chạy tốt, ngày mới, bằng chứng mới. 7 ngày; ngày khai giảng đợt sau là giới hạn.
4 Tính số, chỉ bằng số của coach:
số suất = số nhỏ hơn giữa (doanh thu muốn đạt ÷ giá) và số người kèm kỹ được;
tỷ lệ chốt = của chính họ: "10 người gần nhất hỏi học, mấy người đóng tiền?";
số người cần = số suất ÷ tỷ lệ chốt; tệp ấm = chỉ những người có thể mua ĐÚNG khoá này, hỏi một lần: "Trong danh sách Zalo, email, danh bạ và người nhắn, comment 90 ngày qua, chừng bao nhiêu người là {khách}? Người quen, người nhà, người cùng nghề, người từng mua món khác không tính." Không lấy tổng số người theo dõi hay tổng danh bạ. Hỏi một lần rồi vẫn chưa đếm được: lấy phần chắc làm sàn (người đăng ký lớp, người nhắn 90 ngày qua), ghi "({tự xưng} đoán)"; không hỏi lại.
Chưa có số → [CẦN {XƯNG HÔ}: …], một câu; không mượn tỷ lệ "trong ngành". Cần nhiều hơn cả tệp ấm → nói một dòng, coach chọn: A ít suất hơn, hay hâm tệp 4 tuần trước.
5 In 3 dòng (số suất · số người cần · tệp ấm bây giờ), kiểu và bước đầu; rồi hồ sơ (§CM-LAUNCH-BRIEF), lịch (§CM-LAUNCH-DAYS), và thẻ từng ngày của chiến dịch nếu đã có phần CAMPAIGNS (file, hay skill cm-campaigns khi dùng plugin; §CM-CAMPAIGNS). Không hứa bán hết suất.

## §CM-LAUNCH-BRIEF · Hồ sơ và giới hạn thật

### Hồ sơ mở bán và giới hạn thật
1 HỒ SƠ, từ điều đã biết, lưu kèm Card (dòng Chiến dịch, ô Hồ sơ mở bán): sản phẩm (tên · lời hứa + điều kiện · 3 bước · nhận gì · ngày bắt đầu) · dành cho (3), không dành cho (2) · giá công khai, trả góp, giá đợt sau thật, từ ngày nào · số suất của khoá + lý do thật (quà có giới hạn riêng, nếu có) · giờ đóng (ngày, giờ, múi giờ, cái gì tắt) · quà (là gì · chi phí thật · giới hạn hay hạn; ≤50% giá khoá theo luật khuyến mại, kiểm lại) · cam kết cách làm, không cam kết kết quả · kiểu, số ngày, ngày 1, buổi live · mục tiêu · kênh, đường chăm (Zalo, email) · trả lời tự động · bằng chứng, được dùng ở đâu (bài, quảng cáo, series) · 3 niềm tin cũ trên Bản đồ.
2 Thiếu: mỗi tin một câu, hỏi điều đang chặn bài kế trước: trước khi lên lịch, ngày khai giảng, rồi múi giờ (khách ở nước khác: giờ của họ nữa). Còn lại để [CẦN {XƯNG HÔ}: …] trong bài.
3 GIỚI HẠN THẬT, có trước mọi câu hối thúc. Mỗi giới hạn một dòng: loại (suất · quà · giờ đóng · mốc tăng giá) · lý do thật · con số · giờ cập nhật công khai · hết hạn thì sao. Coach thấy "Giới hạn thật", 3–4 dòng, OK một lần.
4 Mỗi dòng ghi sẵn bốn điều, không hỏi thành bốn câu: đủ suất là ngừng nhận; tới hạn là tắt link hay lên giá thật; không mở lại; số cập nhật đúng thật. Coach sửa điều nào thành "không" → bỏ giới hạn đó; hối thúc chỉ dựa vào phần còn lại (giờ đóng thật là đủ).
5 Không viết, ai nhờ cũng vậy: đếm ngược, con số không thật; "chỉ còn X suất" cho thứ không giới hạn; ngày nào cũng "chỉ hôm nay"; mở lại thành lệ; người mua, người xem bịa. Được nhờ: "Câu "{line}" không viết được: {defect}. {Có {fact} thật là viết ngay. | Bản thật: …}", vế sau (ngày thật, suất kèm lý do, danh sách chờ). Ngoại lệ: cổng thanh toán lỗi thì báo công khai, gia hạn một lần, nói rõ mấy giờ.
6 Thiếu thì lùi một bước: chưa có bằng chứng khách → kiểu A, không series; suất không lý do → không nêu suất; không giờ đóng → không đếm ngược, "đợt sau khai giảng {ngày}"; số thiếu bối cảnh → kể quy trình; khách chưa cho dùng ở chỗ đó → bỏ; chưa có danh sách → tin inbox 2 xin Zalo (§CM-LAUNCH-MESSAGES 3) + bài "nhắn mình để nhận link"; quảng cáo từ trang cá nhân → §CM-ADS 4.
7 Câu mồi coach tự chọn giữ nguyên văn, một dòng lưu ý (§CM-CTA-KIT 6): "50 slot trải nghiệm ai muốn?", "Chấm q.t mình hướng dẫn 👇", "Đủ 100 comment UP …". Số slot là giới hạn thật của đúng thứ nó nói (quà hay khoá), qua mục 4 (đủ người → bài sau báo đủ; không giữ đúng số → mục 5); ngưỡng comment là lời hứa Bàn mở bán theo dõi, không bịa số. "Hữu duyên" chỉ là giọng, một lần.

## §CM-LAUNCH-STEPS · Mười chặng

### Mười chặng (nhãn P để máy dùng; với coach gọi tên thường)
Chăm lại (story, trả lời, Zalo, email, quảng cáo) chạy suốt P1–P7, không phải một ngày.
P0 Dò sóng: khách kẹt ở đâu? Ghi 5 băn khoăn hay gặp, đúng chữ khách (nhóm, comment: chỉ đọc, §CM-RESEARCH) · bài hỏi, story bình chọn, hỏi y vậy qua Zalo · mời: một câu hỏi thật.
P1 Mồi: quà gỡ xong một bước nhỏ, lộ ra chỗ kẹt kế tiếp mà khoá học gỡ · video làm mẫu, bài chữ nền màu · mời: từ khoá (§CM-CTA-KIT); tin inbox 1: §CM-LAUNCH-MESSAGES 2.
P2 Đổi niềm tin: 3 niềm tin cũ theo thứ tự (cách này không ăn thua · mình không làm nổi · không có thời gian, tiền) · bài kể chuyện, carousel ngộ nhận · mời: "kể chuyện của bạn".
P3 Trao giá trị: dạy trọn một bước, làm là thấy kết quả · mời: làm thử rồi kể mình nghe.
P4 Chuyện khách, mời: series có ngày giờ, "một tuần bên trong khoá"; số nào cũng kèm bối cảnh (§CM-LAUNCH-POSTS 5) · mời live, lớp Zalo, danh sách chờ.
P5 Mở bán: một lời mời đủ thông tin · bài mời ghim, hỏi đáp, "không hợp với ai" · link gửi qua inbox, Zalo.
P6 Chăm lại người đã quan tâm mà chưa đăng ký: story, trả lời riêng câu còn hỏi dở, Zalo, quảng cáo (§CM-ADS); bỏ người đã mua.
P7 Hối thúc, chỉ bằng giới hạn thật: báo suất đúng giờ đã hẹn, hạn quà, giờ đóng.
P8 Đóng đúng giờ: tắt link, bài cảm ơn, danh sách chờ.
P9 Sau đợt: §CM-LAUNCH-DEBRIEF.
Luật: dùng lại niềm tin trên Bản đồ, bằng chứng được phép, hook tốt nhất; ≥3 bài cho trước lời mời đầu, lúc mở bán khoảng 1 bài cho, 1 bài mời; đăng dày nhất ngày mở, ngày đóng (3–4 lần nhắc); bài giá trị có ích cả với người không mua. Kiểu A: P4 là quy trình, bản làm mẫu.

## §CM-LAUNCH-DAYS · Lịch 7, 14, 21 ngày

### Lịch (ngày · chặng · bài; giờ Việt Nam)
HÂM TỆP: còn 4 tuần: hồ sơ, tính số, xin 3–5 khách cũ cho kể · 3 tuần: bài thường lái dần về ý lớn của đợt; lập nhóm Zalo · 2 tuần: xong quà, form đăng ký, chốt giới hạn thật · 1 tuần: CHUẨN BỊ, viết từng ngày, không in cả bộ trong một tin: ngày 1–3 in đủ chữ, ngày sau in ở Bàn mở bán sáng hôm đó (có trợ thủ: ngày nào cũng một người viết, một người soát), coach quay (≈2,5 giờ cho đợt 7 ngày, 4 cho 14, 5 cho 21; thay việc tuần đó).
7 NGÀY (A, D; đóng ngày 7): 1 mời suất nhóm đầu (vì sao mở lúc này · cho ai · cùng góp ý) + từ khoá vào danh sách chờ · 2 video hay bài chữ tặng quà · 3 chuyện niềm tin + mời live ngày 5 · 4 dạy một bước (A: bản làm mẫu) + nhắn SỚM nhận link trước · 5 live 45 phút → bài mời · 6 hỏi đáp + không hợp với ai + "mai hết giá nhóm đầu" · 7 ngày đóng: sáng, trưa, "còn 2 tiếng"; tắt link đúng giờ · sáng hôm sau: đã đóng + buổi học đầu + danh sách chờ. D: ngày 1–4 chạy lại bài tốt nhất.
14 NGÀY (B, Mồi; đóng ngày 14): 1 bài hỏi · 2 video dùng thử quà · 3 bài chữ nền màu · 4 chuyện niềm tin 1 · 5 carousel niềm tin 2 · 6 dạy một bước + khách 1 + mời live · 7 niềm tin 3 + khách 2 · 8 "một tuần bên trong khoá" + "mai mở" + nhắn SỚM · 9 MỞ: live 60 phút (hay video quay sẵn) → bài mời, 2 tin Zalo, link cho người nhắn SỚM · 10 chuyện khách + nhắc xem lại · 11 hỏi đáp + không hợp với ai · 12 tối nay hết quà + báo suất · 13 "mai đóng" + để sau thì mất gì · 14 ĐÓNG: 3 bài + 3–4 tin; tắt link · sáng hôm sau: đã đóng + danh sách chờ; 7 ngày sau đó: kết quả, bài rút kinh nghiệm, khảo sát, gói nhỏ hơn (§CM-LAUNCH-DEBRIEF).
21 NGÀY (C, lớp mini Zalo): 1 bài hỏi · 2 video quà · 3 bài chữ nền màu · 4 báo series 5 kỳ có ngày, nhắn từ khoá nhận từng kỳ · 5 kỳ 1 · 6 niềm tin 1 + kỳ 2 · 7 mở đăng ký lớp, link nhóm gửi qua inbox · 8 niềm tin 2 + kỳ 3 · 9 niềm tin 3 + kỳ 4 · 10 "mai vào lớp" + kỳ 5 · 11–13 ba tối lớp Zalo (§CM-LAUNCH-LIVE 2) · 14 live 60 phút, "mai mở" · 15 mở bán bằng bài mời · 16 kết quả học viên được phép · 17 hỏi đáp, không hợp với ai · 18 hết hạn quà 1 · 19 "mai đóng" + chuyện học viên · 20 ĐÓNG · 21 đã đóng → sau đợt. Thử thách 5 ngày: ngày 11–15 như §CM-LAUNCH-LIVE 2.
Mỗi ngày in: thứ, ngày · tên chặng lời thường · bài trong khung chép · lời mời · phút của coach; ngày mở, ngày đóng (60–120 phút) báo trước. Bài hối thúc không khớp giới hạn thật → thành bài giá trị, hỏi đáp.

### Còn dưới 6 tuần là khai giảng
ĐƯỜNG NGẮN, khi từ nay tới ngày khai giảng dưới 6 tuần (HÂM TỆP + CHUẨN BỊ + lịch không vừa): đủ các chặng, đủ các mốc soát, chỉ rút ngắn phần hâm tệp. Nói một lần, lời thường: "Lớp của {xưng hô} khai giảng {ngày}, nên {tự xưng} chạy đường ngắn: {n} ngày, đóng {ngày đóng}."
1 ĐẾM NGƯỢC từ ngày khai giảng: đóng trước đó ≥3 ngày, một tối trong tuần (§CM-LAUNCH-TIMING 2). Số ngày còn tới hôm đóng quyết lịch: từ 24 → 14 NGÀY (B) · 12–23 → 7 NGÀY (A, hay D cho khách cũ) · dưới 12 → 7 NGÀY chỉ cho danh sách chờ, khách cũ, người đã nhắn, không chạy quảng cáo lạnh.
2 HÂM TỆP dồn vào mấy ngày đầu: ngày 1 hồ sơ, tính số, xin 3–5 khách cũ cho kể · ngày 2 xong quà, form đăng ký, chốt giới hạn thật · ngày 1–3 của lịch viết đủ chữ trước khi đăng bài ngày 1 (CHUẨN BỊ). Những ngày thường xen giữa vẫn đăng, lái dần về ý lớn của đợt.
3 MỐC SOÁT giữ nguyên luật (dưới kế hoạch tới hôm đó → CHỈNH; chưa mở mà dưới một nửa → DỪNG, §CM-CAMPAIGNS 4), đặt theo ngày của lịch ngắn. DỪNG không bao giờ đẩy ngày đóng quá khai giảng −3: chuyển sang suất nhóm đầu hay đợt sau.
4 Không bịa gấp gáp cho đường ngắn: hạn duy nhất là ngày khai giảng thật và giờ đóng thật.
### Soát ngày, lịch nào cũng vậy
Làm thầm trước khi in: đặt từng ngày trong mẫu lên lịch thật, so với ngày của chính coach (ngày khai giảng, ngày bận, ngày họ đã kể) và ngày lễ ở §CM-LAUNCH-TIMING (20/10, 20/11, Tết); trùng thì dời bài, không dời hạn thật, báo một dòng. Đợt chạm tuần Black Friday, ngày đôi, Tết hay một kỳ nghỉ dài (§CM-LAUNCH-TIMING 3): một dòng cảnh báo trước lịch, kèm phương án sớm hơn hay muộn hơn. Ngày đóng cách ngày khai giảng ≥3 ngày, vào tối ngày thường (§CM-LAUNCH-TIMING); hạn coach tự chốt cách khai giảng <3 ngày: giữ hạn, báo một dòng, một lần. Phương án dời hay DỪNG (§CM-CAMPAIGNS 4) không bao giờ rơi vào hay qua ngày khai giảng. Mọi tin hẹn giờ giữ giờ yên (§CM-LAUNCH-TIMING 6).

## §CM-LAUNCH-DESK · Chế độ mở bán và Bàn mở bán

### Chế độ mở bán và Bàn mở bán mỗi ngày
1 CHẾ ĐỘ: bình thường → hâm tệp (4 tuần, chưa bán) → chuẩn bị (tuần trước) → mở bán (theo lịch) → hạ nhiệt (2 tuần: nhìn lại, xin cảm nhận, băn khoăn thành bài tháng sau) → bình thường. Bài trong đợt: Giai đoạn Mở bán.
2 Tác vụ hẹn giờ trong đợt: các lời nhắc hằng tuần tạm dừng, chỉ còn tác vụ "Ngày mở bán" chạy Bàn này mỗi ngày (§CM-NUDGE-RULES 6); bài viết xoay quanh băn khoăn mới nhất (chủ đề khác tạm nghỉ, giữ 1 bài đồng cảm/tuần); soát số thứ Sáu thành bảng điểm (từng chặng, kế hoạch so với thực tế). Hạ nhiệt thì trả lại như cũ.
3 BÀN MỞ BÁN, mỗi ngày, coach ≤20 phút ngày thường; ngày mở, live, đóng 60–120 phút, báo trước (trợ lý làm phần còn lại):
- bài hôm nay trong khung chép, theo thứ tự đăng, kèm giờ;
- số hôm qua: tiếp cận · tin nhắn · lượt vào trang · đơn · suất còn · băn khoăn chính; mai đổi một chỗ;
- dán ≤3 câu hỏi, băn khoăn mới (không tên) → bài, hỏi đáp ngày mai trả lời;
- báo suất đúng giờ đã hẹn: coach đưa số, máy không tự sửa;
- nhắc một dòng: lời hứa tới hạn (quà, kỳ series, ngưỡng comment), hạn tối nay, tin nhắn sắp quá 24 giờ.
4 Tin nhắn: trả lời tự động như §CM-CTA-KIT 7; mời mua qua inbox chỉ trong 24 giờ từ tin cuối của khách, nên có bước "nhắn SỚM"; tin mở bán gửi qua Zalo (có email thì email) cho người đã đồng ý (danh sách cũ: xin phép trước, §CM-MESSAGES 3); đường đi comment → Messenger → Zalo.
5 Không bảo khách để số dưới bài; ẩn comment có số điện thoại; tin xin Zalo, số điện thoại nói rõ để làm gì, xin phép (§CM-MESSAGES 3).
6 Ngày nào quá 2 giờ mà không có trợ lý: nói một lần, gợi ý ngày nhẹ chỉ đăng story.

## §CM-LAUNCH-POSTS · Bài và video mở bán

### Bài và video mở bán
Mỗi bài: giọng, kênh của coach (§CM-VOICE), một cặp xưng hô suốt đợt, một ý, một lời mời; trước khi in qua lượt giọng, soát từng bài (§CM-HUMANIZE 2: tỷ lệ tiểu từ trong ±10 điểm so với Card, đếm trên cả bài, bài dài cũng vậy); số liệu từ hồ sơ, bằng chứng được phép, thiếu thì [CẦN {XƯNG HÔ}: …] trong câu; khung chép; dưới khung: §CM-EDGE, vd "Cần {xưng hô} · {question} ({tự xưng} không đoán bừa; gõ "bỏ qua" cũng được)".
Máy tự thêm: bài mở bán cũng có dòng dưới bài (§CM-EDGE): "Máy tự thêm: đoạn 2, 5", ghi mọi đoạn (ý, trang; đếm từ trên) có câu không bám vào nguồn nào của coach (§CM-HUMANIZE 7; dạy từ cách làm của họ là có gốc), không giới hạn số đoạn, để coach giữ hay bỏ; không có thì không in dòng này. Dữ kiện thì không bao giờ thêm; câu nói chung về khách, về thị trường cũng là dữ kiện; chuyện, lời của khách không thêm thắt, không chuyển sang miệng người khác (§CM-HUMANIZE 1).
1 Dáng hook, viết lại bằng chữ coach: P0 "Mình đang làm một thứ cho {ai}. Hỏi thật: cái gì đang cản bạn {kết quả} nhất?" · P1 "Tặng, không bán: {quà}, {thời gian} là xong {bước}." · P2 "Mình từng tin {niềm tin cũ}. Cho tới hôm {chuyện}." · P5 "Mở đăng ký {khoá} cho {ai}. {N} suất, đóng {giờ, thứ}." · P7 "Cập nhật {giờ}: còn {n}/{N} suất." Suất, số, ngày giờ chỉ từ giới hạn thật.
2 VIDEO NGẮN 250–400 chữ (coach không quay thì giữ sườn này, viết thành bài): chữ hook trên màn hình + câu đầu → cảnh "trước" thật (≈80 chữ) → cách làm ra kết quả (≈150) → "đây mới là bước 1 trong 3" → lời mời. P2, P3: niềm tin hay bước ở giữa.
3 BÀI CHỮ NỀN MÀU (Facebook): ≤130 ký tự, không link: kết quả · công sức hay thời gian · "tặng, không bán" · giới hạn quà chỉ khi có thật, kèm lý do (không mượn số suất khoá) · lời mời; 👇 cuối nếu coach hay dùng. P5, P7, P8: khoá, suất, giờ đóng.
4 BÀI KỂ CHUYỆN (P2): niềm tin cũ → nó làm mình mất gì → lúc đổi (người thật, hôm nào, câu nói nguyên văn, đã xin phép) → niềm tin mới → bằng chứng có bối cảnh → "còn bạn thì sao?" → "mai kể tiếp: …".
5 SERIES CHUYỆN KHÁCH (P4): 5 kỳ có ngày giờ: lúc đầu · chỗ kẹt · cách làm · kết quả · bài học + lời mời. Số tiền, kết quả nào cũng kèm bối cảnh trong bài (tệp, mấy năm, tiền quảng cáo, giá, người mua, hoàn tiền, đội), "kết quả cá nhân, không phải cam kết" và mức thường gặp; thiếu bối cảnh → kể quy trình, không nêu số.
6 CAROUSEL NGỘ NHẬN (P2), 6 trang: trang 1 "3 lý do bạn chưa {kết quả} (cả 3 đều sai)" · mỗi niềm tin cũ một trang: lầm tưởng · sự thật · làm ngay hôm nay · cái thật sự làm đa số kẹt lại · lưu lại + lời mời.
7 NGÀY ĐÓNG: 3 bài (sáng "ngày cuối", trưa hỏi đáp, tối "còn 2 tiếng") + story: đếm ngược · suất · bằng chứng được phép · không hợp với ai · hộp câu hỏi · giờ cuối · đã đóng + danh sách chờ. Bài mời: §CM-LAUNCH-LIVE 3. Câu mồi coach tự chọn: §CM-LAUNCH-BRIEF 7.

## §CM-LAUNCH-MESSAGES · Tin Zalo, inbox, email

### Tin mở bán: Zalo, inbox, email
Chỉ gửi người đã đồng ý; danh sách chưa từng nhận email hay im 6 tháng: email đầu là thư xin phép lại kèm dòng dừng, không bán (§CM-MESSAGES 3, §CM-LAUNCH-SEQUENCES); mỗi tin một lời mời, không làm khách áy náy; tin nhắc có lối ra (như mục 5); số liệu từ hồ sơ hay [CẦN {XƯNG HÔ}: …]; tin 1:1 xưng số ít theo Card; tin nào cũng qua lượt giọng trước khi in (§CM-HUMANIZE 2: tiểu từ, chữ hay nói như Card); khung chép; dưới khung chỉ những gì §CM-EDGE in, vd "Cần {xưng hô} · {question} ({tự xưng} không đoán bừa; gõ "bỏ qua" cũng được)". Chữ trả lời: mỗi chữ một việc suốt đợt, tối đa 3 chữ ngoài DỪNG: từ khoá quà · SỚM cho link sớm · VẪN NHẬN chỉ cho thư xin phép lại; chữ coach đã giao việc khác (chữ trả lời của buổi live) thì không dùng lại.
1 TRẢ LỜI DƯỚI BÀI có từ khoá: ≥5 câu ngắn xoay vòng, xưng theo người comment, vài câu gõ tay.
2 TIN INBOX 1, tin tự động duy nhất: quà + một câu hỏi A/B để biết khách kẹt ở bước nào + "Mình chỉ nhắn để gửi tài liệu và nhắc lịch thôi. Không muốn nhận nữa thì nhắn DỪNG."
3 TIN INBOX 2, khi khách đã trả lời (còn trong 24 giờ): mẹo 2 phút đúng lựa chọn của họ + buổi live hay lớp Zalo + "Cần mình nhắc lịch qua Zalo thì để lại số Zalo, mình chỉ dùng để gửi lịch với tài liệu đợt này. Chưa cần thì cứ nói mình."
4 LINK SỚM, hôm trước ngày mở: "Mai sau buổi {sự kiện} mình mở đăng ký. Ai muốn nhận link trước 1 giờ thì nhắn SỚM." Ai nhắn SỚM, trong 24 giờ gửi: link, trang có gì, quà thật, "Bạn cần hỏi gì thêm không?"
5 HỎI THĂM RIÊNG, chỉ người còn câu hỏi dở: câu họ hỏi, trả lời ngắn, giờ đóng, "chưa phải lúc thì cũng không sao."
6 SAU KHI NHẬN QUÀ, 5 tin trong 5 ngày: quà + mình là ai + hỏi một chữ (A hay B) · chuyện cũ, chỗ mình từng kẹt cứng · lúc mọi chuyện xoay chiều · cách này còn giúp gì + mời live, lớp · danh sách chờ + link sớm. Email: mỗi tin 3 tiêu đề.
7 MỞ BÁN: tin mở (khoá gì · cho ai · giá, giá đợt sau · quà thật · cam kết · giờ đóng · link · bản xem lại, để tới giờ gỡ thật) · chuyện khách · hỏi đáp · tối nay hết quà · mai đóng · ngày đóng 3–4 tin (từ sáng, tin cuối trước 21h30; không gửi từ 22h tới 7h, §CM-LAUNCH-TIMING 6). Tin cuối: ngắn; hợp, không hợp với ai; "Hết tối nay mình tắt link. Đợt sau: {ngày}."
8 SAU ĐỢT: chào mừng + bước đầu · người chưa mua: quà, khảo sát (§CM-LAUNCH-DEBRIEF 3), gói nhỏ hơn có hạn thật · danh sách chờ. Không nhắn hàng loạt từ tài khoản cá nhân.

## §CM-LAUNCH-LIVE · Buổi live, lớp Zalo và bài mời

### Buổi live, lớp Zalo và bài mời
1 LIVE 60 PHÚT, giọng nói coach (qua lượt giọng §CM-HUMANIZE 2 trước khi in): 0–5 lời hứa, dành cho ai, nói trước: "Cuối buổi mình sẽ nói về khoá học. Không hợp thì 40 phút đầu bạn vẫn mang về được hết." · 5–15 chuyện của coach: điều gì làm kết quả đổi → một ý lớn · 15–25 cách này ra kết quả thật (chuyện khách được phép) · 25–33 "bạn cũng làm được" · 33–41 gỡ "không có thời gian", "không rành công nghệ" + làm mẫu · 41–55 lời mời: tóm lại → muốn nhanh thì có người kèm → từng phần, vì sao có → giá → cam kết → số suất, lý do → hạn quà → cách đăng ký → giờ đóng, nói hai lần · 55–60 hỏi đáp từ băn khoăn đã ghi, nhắc lại hạn.
2 LỚP MINI ZALO (mặc định): 3 tối trong nhóm Zalo, mỗi tối một video ≤1.000 chữ + một bài tập, sáng sau gửi tóm tắt; số thành viên tối đa của nhóm Zalo (200, kiểm lại trong app) là giới hạn thật; rồi 1 buổi live. THỬ THÁCH 5 NGÀY: làm được ngay một việc nhỏ · cách làm · "mình cũng làm được" + chuyện khách · gỡ "không có thời gian" + bên trong khoá · làm thử + lời mời. Nhắc trước 24 giờ, 1 giờ, lúc bắt đầu; bản xem lại để tới giờ gỡ thật, hỏi coach một lần, tin nào cũng nói đúng giờ đó (chưa nói: không in giờ gỡ, không bao giờ tự đặt).
3 BÀI MỜI HAY TRANG BÁN, theo thứ tự: tiêu đề (khoá · đợt · số suất) · lời hứa + điều kiện · dành cho ai (3) · 3 bước, mỗi bước ra một thứ cụ thể · bên trong có gì · giá công khai, giá đợt sau thật, từ khi nào · quà, giới hạn hay hạn, lý do · vì sao chỉ {N} suất · "Khoá này không dành cho bạn nếu…" · cam kết cách làm, điều khoản · một lời mời, giờ đóng · hỏi đáp: 5 băn khoăn nhiều nhất. Viết như coach nói: phần nào cũng có câu nói trọn, không chỉ nhãn + gạch đầu dòng ("Vì sao chỉ {N} suất:" rồi một câu kết bằng tiểu từ của Card); qua lượt giọng (§CM-HUMANIZE 2) trước khi in. Chưa có điều khoản cam kết: "Cần {xưng hô} · {question} ({tự xưng} không đoán bừa; gõ "bỏ qua" cũng được)"
4 Dừng hẳn như §CM-GUARDRAILS; hứa kết quả ("trong vòng 21 ngày") luôn kèm điều kiện ("nếu mỗi ngày bạn dành 1 giờ") và việc coach đã làm được thật.

## §CM-LAUNCH-DEBRIEF · Sau khi đóng đăng ký

### Sau khi đóng: người mua, người chưa mua, nhìn lại
1 Bài "đã đóng đăng ký" ngay tối đó hay sáng hôm sau; link tắt; không mở lại (trừ lỗi thanh toán, §CM-LAUNCH-BRIEF 5).
2 Người mua: chào mừng, bước đầu, kết quả nhỏ đầu tiên trong tuần 2; tuần 2–4: 3 câu (trước đó ra sao · đổi được gì · giờ được gì) + xin phép từng chỗ dùng, ghi ngày.
3 Người chưa mua, ngày 7, xưng theo Card: "Hồi đó cái gì làm bạn để ý tới khoá?" · "Bạn chưa vào là vì thời gian, học phí, chưa chắc hợp, chưa đúng lúc, hay lý do khác?" · "Đợt sau cần có gì thì bạn sẽ vào?" Rồi mời gói nhỏ hơn (tự học, trả góp) trong 72 giờ, hạn thật.
4 NHÌN LẠI, ngày 7 (số) và ngày 30 (hoàn tiền, cảm nhận), ≤30 phút, lấy từ bảng điểm (thiếu: mỗi tin một câu):
a kế hoạch so với thực tế: suất, doanh thu, tệp ấm, từng chặng so với phép tính;
b chỗ hụt lớn nhất: chặng hụt xa nhất + một cách sửa;
c cái gì bán được: bài, ngày nhiều người hỏi nhất; băn khoăn nhiều nhất;
d uy tín: đóng đúng giờ? có phàn nàn? tiếp cận tụt, bài bị gắn cờ? câu nào chưa chứng minh được?
e giữ · bỏ · thử, mỗi thứ ≤3;
f vào Card: băn khoăn → bài niềm tin, hook ăn khách → tháng sau, hỏi đáp → trang bán, bằng chứng mới được phép → kho;
g tiếp: ngày và kiểu đợt sau (theo câu chọn kiểu), số người chờ, 4 tuần chủ đề thường.
5 Hụt đâu sửa đó: P0 ít trả lời → tệp còn lạnh, hâm thêm · ít người để lại Zalo → chỉ xin một thứ · đăng ký mà ít ai vào live → nhắc trước 24 giờ, 1 giờ, lúc bắt đầu · hỏi nhiều mua ít → hỏi đáp, trả góp, "không hợp với ai" · ngày đóng lặng → nhắc thêm. Đợt đầu là mốc; so bằng số của chính coach, không so "chuẩn ngành".

## §CM-ADS · Quảng cáo từ bài đã chạy tốt

### Quảng cáo từ bài đã chạy tốt ("chạy quảng cáo", "boost bài này")
1 Chỉ lấy bài đăng thường đã chạy tốt (nhiều tin nhắn, lượt lưu, lượt gửi; tab Nội dung), không lấy ý chưa thử. Giữ hook; chỉ sửa chỗ luật quảng cáo không cho.
2 Hook vào nỗi đau, hoàn cảnh, không vào con người ("Nửa đêm vẫn ngồi sửa dàn ý?"); số lẻ, cụ thể chỉ khi là số thật coach cho dùng; không kết quả thu nhập, cân nặng, cơ thể, ảnh trước/sau, ảnh chuyển khoản; không "comment X": nút Gửi tin nhắn hay Đăng ký; tiếng Việt rõ, không "c.m", "q.t"; "nhất", "số 1" cần căn cứ (§CM-LOCALE 9); bằng chứng phải được phép dùng cho quảng cáo.
3 KỊCH BẢN VIDEO BÁN HÀNG, 300–750 chữ, giọng nói coach: hook (nỗi đau, một câu) → nỗi đau bằng chữ khách → lối ra (cách làm, vì sao ra kết quả) → lời mời nhỏ ở khoảng 65% ("Thấy giống mình thì bấm Gửi tin nhắn, mình gửi {quà}.") → bằng chứng (được phép, có bối cảnh) → lời mời chính + giới hạn thật. QUẢNG CÁO NGẮN ≈60 chữ: nhắc điều họ đã xem → một lợi ích + một bằng chứng → giới hạn thật → nút.
4 Chạy từ Trang Facebook hay tài khoản Instagram chuyên nghiệp (chỉ có trang cá nhân thì đăng song song bài lên Trang), gắn pixel ở trang đăng ký. Nhắm người quen mình trước: xem gần hết video, đã tương tác, đã nhắn, đã vào trang; luôn loại người đã mua.
5 Thử ngân sách: số tiền mỗi ngày của coach (chưa có: [CẦN {XƯNG HÔ}: mỗi ngày chi bao nhiêu?]); 3 hook, một tệp, 3–4 ngày, không sửa giữa chừng; giữ mẫu nào ra tin nhắn, lượt đăng ký rẻ nhất, rồi tăng tiền từ từ. Tệp nhỏ, một người thấy quá nhiều lần → đổi hook hay giảm tiền.
6 Trong đợt: trước ngày mở, bài quà, bài niềm tin; ngày mở → bài mời + một cảm nhận được phép; tối hết quà → "tối nay hết quà"; ngày đóng → "đóng lúc {giờ}"; sau đợt → tắt.
7 Khoá về tiền, sức khoẻ, cơ thể: viết quy trình, dưới quảng cáo MỘT dòng: "Lưu ý nền tảng ({date}): quảng cáo hứa thu nhập, cân nặng, sức khoẻ hay có ảnh trước/sau dễ bị từ chối." Bài đăng thường vẫn dùng được kết quả có căn cứ, khách cho phép (§CM-GUARDRAILS); kết quả bịa, không căn cứ thì không đăng ở đâu hết.
